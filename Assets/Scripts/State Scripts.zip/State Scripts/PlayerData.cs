using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public Vector2 Position;
}